<footer>
	Thanks for visiting the Cake Cupid.
</footer>