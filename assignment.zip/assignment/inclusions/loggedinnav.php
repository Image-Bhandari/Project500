 <nav id="loginnav">
    <div id="primarynav"> 
        <a href ="login.php"> <img src="images/logo.png" alt="logo"/> </a>
    </div>
    <div id="secondarynav">
        <ul class="menu">
            <li>
                <a href="matches.php"> <span>Matches </span> </a>
            </li>
            <li>
                <a href ="msglist.php"> <span> Messages </span> </a>
            </li>
            <?php
            if ($_SESSION['username']=='tutor'){
                ?>
            <li>
                <a href ="stats.php"> <span> Statistics </span> </a>
            </li>
            <?php } ?>
        </ul>
        <div id="profilelink" >
           <a href="profile.php"> <img src="<?php 
           if($_SESSION['img']==null){echo 'images/profile_link_logo.jpg';}
           else{echo $_SESSION['img'];}
           ?>" alt="empty image"/> </a>
           
           <form action="logout.php" method="POST">
			    <button class="logoutstyle">Log out</button>
		    </form> 
        </div>
    </div>
</nav>

