<?php

// Configuration file

$DB_DSN = "mysql:host=localhost;dbname=itech3108_30348272_a1";

$DB_USER = "dbuser";
$DB_PASSWORD = "dbuserpass";