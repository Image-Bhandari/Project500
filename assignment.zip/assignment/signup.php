<?php
//signup page
session_start();
require_once "inclusions/config.php";

$conn = new PDO ($DB_DSN, $DB_USER, $DB_PASSWORD);

if (isset($_POST['submit'])) {
    //transfer values from html form to php variables
    $user_id=$_POST['user_id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    //hashing the password
    $rndstr = base64_encode(openssl_random_pseudo_bytes(32));
    $salt = '$2y$10$' . $rndstr;
    $hash = crypt($password, $salt);
    //echo $hash;
    $rehash = crypt($password, $hash);
    //end of hash
    unset($_POST['submit']);

    //Checks if any checkboxes has been selected or not and executes if atleast one of them is selected
    $len = count($_POST['check_cake']);
    if (($len-1) >0 && ($len-1) <=9) {

        //inserting the values into database
        $stmt = $conn->prepare("insert into user
        (userid,name,email,password) values
        (:user_id, :name, :email, :password)");
        $stmt->bindValue(':user_id',$user_id);
        $stmt->bindValue(':name',$name);
        $stmt->bindValue(':email',$email);
        $stmt->bindValue(':password',$rehash);
        $inserted=$stmt->execute();
        //inserting the cakes that the user selects into likes table
        foreach($_POST['check_cake'] as $selectedcakes){
            //echo "<p>" . $selectedcakes . "</p>";
            $stmt = $conn->prepare("insert into likes
        (cake_id, userid) values 
        (:selectedcakes , :user_id)");
        $stmt->bindValue(':selectedcakes',$selectedcakes);
        $stmt->bindValue(':user_id',$user_id);
        $inserted=$stmt->execute();
        }
        echo '<script> alert("Account has been created!");  </script>';
    }
    else {
        echo '<script> alert("Please select a cake!");  </script>';
    }
}
?>

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit -->
    <!-- file: Signup Page -->
    <!-- Last Modified: 28/04/2020 --> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Sign up </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 

    </head>

    <body>
        <!-- Navigation bar -->
        <nav>
            <div id="navlogo"> 
                <img src="images/logo.png" alt="logo"/>
            </div>
        </nav>

        <!-- Body -->
        <section id="loginsection">
            <article id="pagewrap">
               <ul class="tabs">
                    <li  class="active">
                    <span class="wraptext"> Registration </span>
                    </li>

                    <li>
                    <a href="login.php"> <span class="wraptext"> Log in </span> </a>
                    </li>
               </ul>

               <!--<h2> Sign Up form </h2> -->
            
                <form id="loginform" method="post">
                    <ul>
                        <li>
                            <input type="text" size="10" name="name" id="name" placeholder="Full Name" required/>
                        </li>
                        <li>
                            <input type="text" size="10" maxlength="10" name="user_id" id="user_id" placeholder="username" required/>
                        </li>
                        <li>
							<input type="email" name="email" id="email" placeholder="Please enter your E-mail Address" required/>
						</li>
                        <li>
                            <input type="password" name="password" id="password" placeholder="Password" minlength='5' required/>
                        </li>
                    </ul>

                    <!-- Table to keep the cakes and get the user input -->
                    <table class="caketable">
                         <tr>
                             <h3> Please select our favourite taste of cakes </h3>
                         </tr>
                         <tr id="cake_column_hide">
                               <input type="checkbox" name="check_cake[]" value="0" style="opacity:0;" checked>
                        </tr>
                         <tr>
                        
                            <th class="cake_column">
                                <img src="images/chocolatecake.jpg" alt="Chocolate Cake" class="cakestyle"/> <br>
                                <!-- image retrived from: http://listdose.co/wp-content/uploads/2013/07/choc.jpg -->
                                <input type="checkbox" name="check_cake[]" value="1">
                                Chocolate Cake
                            </th>

                             <th class="cake_column">
                                <img src="images/blackforest.jpg" alt="Black Forest" class="cakestyle"/> <br/>
                                <!-- image retrived from: http://listdose.co/wp-content/uploads/2013/07/blackforest.jpg -->
                                <input type="checkbox" name="check_cake[]" value="2">
                                Black Forest
                            </th>

                            <th class="cake_column">
                                <img src="images/rumcake.jpeg"alt="Rum Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: https://food.fnr.sndimg.com/content/dam/images/food/fullset/2009/1/21/0/SH1302_Rum-Cake.jpg.rend.hgtvcom.826.620.suffix/1371589233039.jpeg -->
                                <input type="checkbox" name="check_cake[]" value="3">
                                Rum Cake 
                            </th>
                         </tr>
                         <tr>
                            <th class="cake_column">
                                <img src="images/redvelvet.jpg" alt="Red Velvet Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: http://listdose.co/wp-content/uploads/2013/07/red.jpg -->
                                <input type="checkbox" name="check_cake[]" value="4">
                                Red Velvet Cake
                            </th>
                             <th class="cake_column">
                                <img src="images/bananacake.jpg" alt="Banana Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: https://keyassets-p2.timeincuk.net/wp/prod/wp-content/uploads/sites/53/2018/09/Banana-cake-recipe-1920x1263.jpg -->
                                <input type="checkbox" name="check_cake[]" value="5">
                                Banana Cake
                            </th>
                            <th class="cake_column">
                                <img src="images/carrotcake.jpg" alt="Carrot Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: http://listdose.co/wp-content/uploads/2013/07/carrot.jpg -->
                                <input type="checkbox" name="check_cake[]" value="6">
                                Carrot Cake
                            </th>
                        </tr>
                        <tr>
                            <th class="cake_column">
                                <img src="images/vanillacake.jpg" alt="Vanilla Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: https://cdn.sallysbakingaddiction.com/wp-content/uploads/2019/01/vanilla-cake.jpg -->
                                <input type="checkbox" name="check_cake[]" value="7">
                                Vanilla Cake
                            </th>
                             <th class="cake_column">
                                <img src="images/pavlova.jpg" alt="Pavlova Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Christmas_pavlova.jpg/1280px-Christmas_pavlova.jpg -->
                                <input type="checkbox" name="check_cake[]" value="8">
                                Pavlova Cake
                            </th>
                            <th class="cake_column">
                                <img src="images/pineapplecake.jpg" alt="Pineapple Cake" class="cakestyle"/> <br/>
                                <!-- image retrived from: http://listdose.co/wp-content/uploads/2013/07/pineapple.jpg -->
                                <input type="checkbox" name="check_cake[]" value="9">
                                Pineapple Cake
                            </th>
                        </tr>
                    </table> 
                    <input type="submit" name="submit" value="Create Your Account" id="signup_button"/>
                </form>
            </article>
            
        </section>

    <?php include "inclusions/footer.php"; ?>    
    </body>
</html>