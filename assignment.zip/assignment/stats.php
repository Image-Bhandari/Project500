<?php session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";
require_tutor_login();
// you have to be logged in as tutor to view this page
// This function is in utils.php


$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
$loggeduser = $_SESSION['username'];
 
$nam = Array(); // to store the day name
$valu=Array();  // to store the repeatation of day

// importing the day from datetime column from message table
$query = ("SELECT DAYNAME(datetime) AS WeekDay FROM message;"); 
$data = $conn->prepare("$query");
$data->execute();

// getting the number of times messages has been done in a day
foreach ($data as $day) {
    $val=1; 
    //searching the name of day in variable $nam and if it's already present increase the $valu by 1 
    if(in_array($day['0'],$nam)){
        $valu[array_search($day['0'],$nam)]= $valu[array_search($day['0'],$nam)]+1;
    }
    //if the name of the day in variable $nam isn't present then it will assign the name in $nam with a value of 1 in $val
    else{
        array_push($nam,$day['0']);
        array_push($valu,$val);
        }
}
// sorting the days from maximum no of msgs in a day to lowest
// to sort the days with maximum number of $valu (i.e. no. of msgs) to the minimum number of $valu
for($i=0;$i<count($valu);$i++){
    $sorted_array[$i] = $nam[array_search(max($valu),$valu)];
    // making the value of $valu 0 so that the $sorted_array won't have repeated $nam with highest $valu
    // it is because the $sorted_array is updating itself with the highest $valu
    $valu[array_search(max($valu),$valu)]=0;
}

// getting all the data from likes table
$queryc = ("SELECT * FROM likes;"); 
$datac = $conn->prepare("$queryc");
$datac->execute();
$cakeid = Array(); // to store cake id
$likes_count = Array(); // to store number of times a cake has been liked
$cakes_sorted = Array(); // to sort the cakes in descending order by number of likes
foreach ($datac as $like) { 
    $val=1; 
    //searching the cake_id in variable $cakeid and if it's already present increase the $likes_count by 1 
    if(in_array($like['0'],$cakeid)){
        $likes_count[array_search($like['0'],$cakeid)]= $likes_count[array_search($like['0'],$cakeid)]+1;
    }
    //if the cake_id in variable $cakeid isn't present then, it will assign the cake_id in $cakeid with a value of 1 in $likes_count
    else{
        array_push($cakeid,$like['0']);
        array_push($likes_count,$val);
        }
}
// sorting the days from maximum no of msgs in a day to lowest
// to sort the days with maximum number of $valu (i.e. no. of msgs) to the minimum number of $valu

for($i=0;$i<count($likes_count);$i++){
    $cakes_sorted[$i] = $cakeid[array_search(max($likes_count),$likes_count)];
    // making the value of $valu 0 so that the $cakes_sorted won't have repeated $nam with highest $valu
    // it is because the $cakes_sorted is updating itself with the highest $valu
    $likes_count[array_search(max($likes_count),$likes_count)]=0;
}
?> 

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit --> 
    <!-- file: Stats Page -->
    <!-- Last Modified: 10/05/2020 --> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Stats</title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
        <script src="message.js"> </script>
    </head>

    <body>
        <!-- Navigation bar -->
        <?php include "inclusions/loggedinnav.php"; ?>

        <!-- Body Contents -->
        <section id="centrealign">
        <h2> Hi! <?php echo $_SESSION['name']; ?> </h2> <br/>

        <p> Statistics from the website </p>
        <table class="statstable"> 
        <tr> 
            <th> <p> Total Number of Messages sent so far on the site: </p> </th>
            <th> <?php  $query = ("SELECT COUNT('1') FROM message"); 
                        $stmt = $conn->prepare("$query");
                        $stmt->execute();
                        foreach($stmt as $row) {echo $row['0'];} ?>
            </th>
        </tr>

        <tr> 
            <th> <p> The most popular day of the week for sending messages: </p> </th>
            <th> <?php  echo $sorted_array ['0']; ?>
            </th>
        </tr>
            
        <tr>
            <th> The most liked cakes:</th>
            <th> <?php 
                    for ($i=0; $i <= 2; $i++) {
                    $queryca = ("SELECT * FROM cake where cake_id=$cakes_sorted[$i];"); 
                    $dataca = $conn->prepare("$queryca");
                    $dataca->execute();
                    $aaa=$dataca->fetch();
                    echo $aaa['cake_title'].'<br>';
                    }
                ?>
            </th>
        </tr>
        </table>
        </section>

        <?php include "inclusions/footer.php"; ?>
    </body>
</html>