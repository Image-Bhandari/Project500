<?php
session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";
$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
// you have to be logged in to view this page
// This function is in utils.php
require_login();
$loggeduser = $_SESSION['username'];
$receveid = $_SESSION['receiver_id'];
$reciname = $_SESSION['reciname'];

$query = ("SELECT * FROM message WHERE (from_user_id=:loggeduser AND to_user_id=:receveid)
OR (from_user_id=:receveid AND to_user_id=:loggeduser)");
$stmt=$conn->prepare($query);
$stmt->bindValue(':loggeduser',$loggeduser);
$stmt->bindValue(':receveid',$receveid);
$stmt->execute();

foreach($stmt as $key){
   if($loggeduser == $key['from_user_id'])
   {
      echo '<div id="sendmsgbox">';
      echo $key['datetime'] .'            '. $key['text'].'<br/>';
      
      echo '</div>';
   } 
   else{
      echo '<div id="receivemsgbox">';
      echo $key['text']. $key['datetime'].'<br/>';
      echo '</div>';
   }      
}
?>