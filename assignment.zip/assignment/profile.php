<?php session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";

// you have to be logged in to view this page
// This function is in utils.php
require_login();

$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
$loggeduser = $_SESSION['username'];



//uploading the image to the server
if(isset($_POST["submit_pp"])) {
    $target_dir = "images/profilepictures/";
    $target_file = $target_dir .$_SESSION['username'].'.jpg';
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        $bio_img='images/profilepictures/'.$_SESSION['username'].'.jpg';
        $query = "UPDATE user SET photo_url='$bio_img' WHERE userid = '$loggeduser'";
        //updating the Profile field of logged in user into database
        $stmt = $conn->prepare("$query");
        // $stmt->bindValue(':photo_url',$bio_img);
        $inserted=$stmt->execute();
      }
       else {
        echo "Sorry, there was an error uploading your file.";
      }
}

    //updating the profile (biography) field
    if (isset($_POST['submit'])) {
        //transfer values from html form to php variables
        $bio_text=$_POST['bio_text'];
        $query = "UPDATE user SET profile='$bio_text' WHERE userid = '$loggeduser'";
        //updating the Profile field of logged in user into database
        $stmt = $conn->prepare("$query");
        $stmt->bindValue(':profile',$bio_text);
        $inserted=$stmt->execute();
    }
?>

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit -->
    <!-- file: Profile Page -->
    <!-- Last Modified: 10/05/2020 --> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Profile </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
        <script src="message.js"> </script>
    </head>

    <body>
        <!-- Navigation bar -->
        <?php
            include "inclusions/loggedinnav.php"; 
        ?>
        
        <section id="profile-bgimg">
            <div id="profile_img">  
                <div id="photobox">
                    <img src="<?php 
           if($_SESSION['img']==null){echo 'images/profile_link_logo.jpg';}
           else{echo $_SESSION['img'];}
           ?>"/>
                    <span id="addimgbtn">
                        +
                    </span>
                </div>    
            </div>

            <div id="profiletext"> 
            <p>  <?php echo $_SESSION['name']; ?> </p> <br/>
            </div>
        </section>

        <section id="profile_body">

            <form id="user_bio" method="post"> 
                <p class="bio_type"> About </p>
                <input type="text" name="bio_text" id="bio_text" placeholder="Please Include Something about you" 
                value="<?php
                            $query = ("SELECT * FROM user"); $stmt = $conn->prepare($query); 
                            $stmt->execute();  
                            foreach($stmt as $row) 
                                {if($row['userid']==$loggeduser) {echo $row['profile'];}}
                        ?>"/> <br/>
                <input type="submit" name="submit" value="Update your Biography" id="bio_button" onclick="give_alert()"/>
            </form>
            
            <form id="user_picture" method="post" enctype="multipart/form-data">
                <p class="bio_type"> Picture </p> <br/>
                <p> Please try to upload jpg/jpeg image files. Other image file formats may cause some error in displaying the image.</p>
                <input type="file" id="fileToUpload" name="fileToUpload"/><br/>
                <input type="submit" name="submit_pp" id="bio_button" value="Upload Picture">
            </form>

        </section>
    
    <?php include "inclusions/footer.php"; ?>
    </body>
</html>