
		alert("password one and two must be same!");

		function password_validation()
{ 
	var firstpassword=document.f1.password.value;  
	var secondpassword=document.f1.reenterpw.value;  

	if (firstpassword==secondpassword)
		{  
			return true;  
		}  
	else
		{  
			alert("The passwords you entered doesnot match!");  
			return false;  
		}  
};


// name="f1" action="/JavaScript/Index" onsubmit="return password_validation()";