function get_message(){
	
	var xmlHttp = new XMLHttpRequest();
	xmlHttp.open('POST','conversation.php',true);
	var data = new FormData();
	data.append('call','a'); //just to establish a connection
	xmlHttp.onreadystatechange = function()
	{
		if(xmlHttp.readyState > 3){
			var cov = document.getElementById('msgbox');
			cov.innerHTML = xmlHttp.responseText;
			setInterval(get_message,10000);
		}
	};
	xmlHttp.send(data);
}

function give_alert(){
	alert("Your Bio has been updated successfully");
}