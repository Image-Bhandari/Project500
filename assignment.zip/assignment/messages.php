<?php
 session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";
$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
// you have to be logged in to view this page
// This function is in utils.php
require_login();


if(isset($_POST['send'])){
  
    $loggeduser = $_SESSION['username'];
    $receveid = $_SESSION['receiver_id'];
    $txtfield=$_POST['txtfield'];
    date_default_timezone_set('Australia/Sydney');
    $dateandtime = date('Y-m-d H:i:s');
    $con = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
    $query = ("insert into message(from_user_id,to_user_id,datetime,text) values(:loggeduser,:receveid,:dateandtime,:txtfield)");
    $stmt=$con->prepare($query);
    $stmt->bindValue(':loggeduser',$loggeduser);
    $stmt->bindValue(':receveid',$receveid);
    $stmt->bindValue(':dateandtime',$dateandtime);
    $stmt->bindValue(':txtfield',$txtfield);
    unset($_POST['send']);
    //executing the code so the message gets stored in database
    $stmt->execute();
}

if(isset($_GET['to'])){
    $query = ("SELECT * FROM user WHERE userid= :to");
    $stmt = $conn->prepare($query);
    $stmt->execute($_GET);
    foreach($stmt as $key){
    //  echo $key['name'];
    $_SESSION['reciname']=$key['name']; 
    $_SESSION['receiver_id']=$key['userid'];
    }
}
?>

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit -->
    <!-- file: Messages Page -->
    <!-- Last Modified: 28/04/2020 --> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Messages </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
        <script src="message.js"> </script>
    </head>

    <body onload="get_message()">
        <!-- Navigation bar -->
        <?php
            include "inclusions/loggedinnav.php"; 
        ?>
        
        <section id="centrealign">
           <article class="msgto"> <span> To: <?php echo $_SESSION['reciname'];?> </span> </article>
           
           <form method="POST" action="messages.php">
                <div id="msgbox">
                </div>

                <div id="sending_field">
                    <input type="text" placeholder="Type your message..." name="txtfield" id="msgtxt"/>
                    <input type="submit" value="Send Message" name="send" id="msgbtn"/>
                </div>
            </form>

        </section>

    <?php include "inclusions/footer.php"; ?>    
    </body>
</html>