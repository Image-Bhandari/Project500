<?php
session_start();
require_once "inclusions/config.php";
require "inclusions/utils.php";
require_once "inclusions/auth.php";
?>
<?php
	// get_or_default is in utils.php
	// get the variables from the form in the webpage
	$user_id = get_or_default($_POST, 'user_id', '');
	$password = get_or_default($_POST, 'password', '');

	//gets user_id and password after user clicks the login button
	if($user_id and $password) {
		
		// Use the DB to authenticate a user
		// getting the values from database
		$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);

		// getting the input from form using ? and checking with the db
		$query = "SELECT userid, password, name, photo_url FROM user WHERE userid=?";

		$stmt = $conn->prepare($query);
		$stmt->bindValue(1, $user_id);

		// If the execution works properly
		if($stmt->execute())
		{
			// Grab the first row
			$row = $stmt->fetch();

			// If it exists
			if($row) {
				// Get the stored password
                $db_password = $row['password'];
                $_SESSION['img'] =$row['photo_url'];
                $_SESSION['name'] = $row['name'];
                // Check whether the hash of the password is the same as
				// the one in the database
				if(password_verify($password, $db_password))
				{
                    login($user_id);
					header('Location: matches.php');
					exit;
				}
			}
		}

		mysqli_stmt_close($stmt);
	}
?>

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit -->
    <!-- file: login page -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Login </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
    </head>

    <body>
        <!-- Navigation bar -->
        <nav>
            <div id="navlogo"> 
                <img src="images/logo.png" alt="logo">
            </div>
        </nav>

        <section id="loginsection">
            <article id="pagewrap">
                <?php if(is_logged_in()): ?>
                <h2>Currently logged in as <?php echo htmlentities(logged_in_user()); ?></h2>
                <form action="logout.php" method="POST">
                    <button>Log out</button>
                </form>
                
                <?php else: ?>
                    <ul class="tabs">
                        <li>
                        <a href="signup.php"> <span class="wraptext"> Registration </span></a>
                        </li>

                        <li class="active">
                        <span class="wraptext"> Log in </span>
                        </li>
                    </ul>

                    <h2> Log in </h2>

                    <form action="login.php" method="POST">
                        <?php if($user_id) : ?>
                            <div class="warning">Login failed, please try again</div>
                        <?php endif; ?>
                        <ul>
                            <li>
                                <input type="text" size="10" maxlength="10" name="user_id" id="user_id" placeholder="Username"
                                value="<?php echo htmlentities($user_id); ?>">
                            </li>

                            <li>
                                <input type="password" size="10" name="password" id="password" placeholder="Password">
                            </li>
                        </ul>
                        
                        <input type="submit" name="submit" value="Log In" id="login_button"/>
                    </form>
                 <?php endif; ?>
            </article>
        </section>
       
        <?php include "inclusions/footer.php";?>
    </body>
</html>