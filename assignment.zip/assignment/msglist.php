<?php
 session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";
$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
// you have to be logged in to view this page
// This function is in utils.php
require_login();
$chat_list = Array();
$username = $_SESSION['username'];
$query = ("SELECT from_user_id,to_user_id FROM message where from_user_id=:username OR to_user_id=:username");
$stmt = $conn->prepare($query);
$stmt->bindValue(':username',$username);
$stmt->execute();
foreach($stmt as $value){
    // var_dump ($value);
    // echo '<br/>';
    if((in_array($value['from_user_id'],$chat_list) || in_array($value['to_user_id'],$chat_list))){
   
}
else{
    if($value['from_user_id']!=$username){
        array_push($chat_list,$value['from_user_id']);
    }
    if($value['to_user_id']!=$username){
        array_push($chat_list,$value['to_user_id']);
    }
}
}

?>

<!DOCTYPE html>
<html>
    <!-- Author: Surag Pandit -->
    <!-- file: Message list Page -->
    <!-- Last Modified: 28/04/2020 --> 
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Messages </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
        <script src="message.js"> </script>
    </head>

    <body>
        <!-- Navigation bar -->
        <?php
            include "inclusions/loggedinnav.php"; 
        ?>

        <section id="centrealign">

        <?php 
        $con = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
             
        for($x=0; $x<count($chat_list);$x++){
            
            $query_sec ="SELECT name,userid, photo_url from user where userid =:chat_name";
            $ques=$con->prepare($query_sec);
            $ques->bindValue(':chat_name',$chat_list[$x]);
            $ques->execute();
            
            if(count($chat_list)==1){
                 $que=$ques->fetch();

                if($que['photo_url']==null)
                {$pp='images/profile_link_logo.jpg';}
                else
                {$pp=$que['photo_url'];}
                    echo '<div id="matchlist">'; 
                    echo '<div id="left_img">';
                    echo  '<img src="'.$pp.'" alt="image"/>';
                    echo '</div>';
                    echo '<div id="right_contents">';
                        echo '<span class="profile_name">'.$que['name'] .'<br/> </span>';
                        echo ' <a href="messages.php?to='. $que['userid'].'">Message</a> ';
                    echo '</div>';
                    echo '</div>';
              
        }
            else{
                foreach($ques as $row) {
                    if($row['name']!=$_SESSION['name']){
                        if($row['photo_url']==null)
                        {$pp='images/profile_link_logo.jpg';}
                        else
                        {$pp=$row['photo_url'];}
                        echo '<div id="matchlist">'; 
                        echo '<div id="left_img">';
                        echo  '<img src="'.$pp.'" alt="emage"/>';
                        echo '</div>';
                        echo '<div id="right_contents">';
                            echo '<span class="profile_name">'.$row['name'] .'<br/> </span>';
                            echo ' <a href="messages.php?to='. $row['userid'].'">Message</a> ';
                        echo '</div>';
                        echo '</div>';
                    }   
                } 
            }
        }
        ?>

        </section>

        <?php include "inclusions/footer.php"; ?>    
    </body>
</html>