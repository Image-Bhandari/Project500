<?php session_start();
require "inclusions/config.php";
require "inclusions/utils.php";
require "inclusions/auth.php";

// you have to be logged in to view this page
// This function is in utils.php
require_login();
$conn = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);

//SORTING MESSAGE
$chat_list = Array();
$username = $_SESSION['username'];
$query_mes = ("SELECT from_user_id,to_user_id FROM message where from_user_id=:username OR to_user_id=:username");
$stmt = $conn->prepare($query_mes);
$stmt->bindValue(':username',$username);
$stmt->execute();
foreach($stmt as $value){ 
      if((in_array($value['from_user_id'],$chat_list) || in_array($value['to_user_id'],$chat_list))){
   
}
else{
    if($value['from_user_id']!=$username){
        array_push($chat_list,$value['from_user_id']);
    }
    if($value['to_user_id']!=$username){
        array_push($chat_list,$value['to_user_id']);
    }
}
}
// END OF SORTING MESSAGE

//SORTING LIKES
$name = Array(); //to get user name from db (like table)
$values = Array(); //to count the likes with other users from db (like table)
$que_like = "SELECT * FROM likes where cake_id in (Select cake_id from likes where userid=:log_user)";
$stmt_like = $conn->prepare($que_like);
$stmt_like->bindValue(':log_user',$_SESSION['username']);
$stmt_like->execute();
$sorted_array= Array(); //to sort the userid from the highest match to lowest match



foreach ($stmt_like as $key) {
    $val=1;
    if($_SESSION['username']!=$key['userid']){
        if(in_array($key['userid'],$name)){
          $values[array_search($key['userid'],$name)]= $values[array_search($key['userid'],$name)]+1;
         
        }
        else{
            array_push($name,$key['userid']);
            array_push($values,$val);
            }
    }
}
for($i=0;$i<count($values);$i++){
   $sorted_array[$i] = $name[array_search(max($values),$values)];
   $values[array_search(max($values),$values)]=0;
}
// END OF SORTING LIKES
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Cake Cupid - Matches </title>
        <link rel="stylesheet" type="text/css" href="css/scripts.css"> 
    </head>

    <body>
        <!-- Navigation bar -->
        <?php
            include "inclusions/loggedinnav.php"; 
        ?>
       
        <section id="centrealign">
            <!-- $_SESSION['name'] is made global and it is transmitting the logged in user's Name -->
            <h2> Hi! <?php echo $_SESSION['name']; ?> </h2> <br/>
            <p> MATCHES </p>
            <?php
            for($i=0;$i<count($sorted_array);$i++){   
                $query = "SELECT * FROM user where userid=:id";
                $stmt = $conn->prepare($query);
                $stmt->bindValue(':id',$sorted_array[$i]);
                $stmt->execute();
                    foreach($stmt as $row) {
                        if($row['name']!=$_SESSION['name']){
                            if($row['photo_url']==null)
                            {$pp='images/profile_link_logo.jpg';}
                            else
                            {$pp=$row['photo_url'];}

                            if(in_array($row['userid'],$chat_list)){}
                            else{
                            echo '<div id="matchlist">'; 
                            echo '<div id="left_img">';
                                echo  '<img src="'.$pp.'" alt="image"/>';
                            echo '</div>';
                            echo '<div id="right_contents">';
                                echo '<span class="profile_name">'.$row['name'] .'<br/> </span>';
                                echo $row['profile'] . '<br/>';
                                echo ' <a href="messages.php?to='. $row['userid'].'">Message</a> ';
                            echo '</div>';
                            echo '</div>';
                        }  
                    }
                }
            }
            ?>
           
        </section>

    <?php include "inclusions/footer.php"; ?>
    </body>
</html>