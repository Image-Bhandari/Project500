-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2020 at 05:47 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itech3108_30348272_a1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cake`
--

CREATE TABLE `cake` (
  `cake_id` int(11) NOT NULL,
  `cake_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cake`
--

INSERT INTO `cake` (`cake_id`, `cake_title`) VALUES
(1, 'Chocolate Cake'),
(2, 'Black Forest'),
(3, 'Rum Cake'),
(4, 'Red Velvet Cake'),
(5, 'Banana Cake'),
(6, 'Carrot Cake'),
(7, 'Vanilla Cake'),
(8, 'Pavlova Cake'),
(9, 'Pineapple Cake');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `cake_id` int(11) DEFAULT NULL,
  `userid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`cake_id`, `userid`) VALUES
(1, '30348272'),
(2, '30348272'),
(3, '30348272'),
(4, '30348272'),
(5, '30348272'),
(6, '30348272'),
(7, '30348272'),
(8, '30348272'),
(9, '30348272'),
(1, 'tutor'),
(2, 'tutor'),
(4, 'tutor'),
(7, 'tutor'),
(9, 'tutor'),
(1, '30349096'),
(3, '30349096'),
(5, '30349096'),
(7, '30349096'),
(9, '30349096'),
(6, '30347990'),
(7, '30347990'),
(8, '30347990'),
(9, '30347990'),
(1, '30350175'),
(2, '30350175'),
(3, '30350175'),
(4, '30350175'),
(5, '30350175'),
(7, '30350175'),
(8, '30350175'),
(0, 'tutor'),
(1, 'tutor'),
(2, 'tutor'),
(4, 'tutor'),
(7, 'tutor'),
(0, 'tutor'),
(1, 'tutor'),
(2, 'tutor'),
(4, 'tutor'),
(7, 'tutor');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `from_user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `datetime` datetime NOT NULL,
  `text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`from_user_id`, `to_user_id`, `datetime`, `text`) VALUES
('30348272', 'tutor', '2020-05-05 10:10:01', 'test message'),
('tutor', '30348272', '2020-05-06 23:10:12', 'Hi!'),
('30348272', 'tutor', '2020-05-06 23:10:45', 'Hello'),
('tutor', '30347990', '2020-05-06 23:27:04', 'Hi Bibek'),
('tutor', '30350175', '2020-05-07 00:16:38', 'Hello Aawesh'),
('30349096', 'tutor', '2020-05-07 00:43:04', 'Hi Sir'),
('30348272', '30347990', '2020-05-07 02:39:22', 'hi'),
('30348272', '30349096', '2020-05-08 22:58:03', 'How are you?'),
('30349096', '30348272', '2020-05-08 22:58:34', 'Not good'),
('30349096', '30348272', '2020-05-08 22:58:42', 'I am having a lot of problems'),
('30348272', '30349096', '2020-05-08 22:58:59', 'Dont worry you will be fine'),
('30348272', '30349096', '2020-05-08 22:59:09', 'Dont worry much, you will be fine'),
('30347990', '30348272', '2020-05-08 23:07:33', 'Sure'),
('30348272', '30347990', '2020-05-08 23:07:48', 'Cool');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `email`, `password`, `profile`, `photo_url`) VALUES
('30347990', 'Bibek Dulal', 'bibek11112222@gmail.com', '$2y$10$fhniv9I56HdLZlWBpJlLaeCoHln2zfhT1bWp9DliHzfIreU1nnx1K', '', ''),
('30348272', 'Surag Pandit', 'suragpandit@gmail.com', '$2y$10$8MKTqSBydy47o0OYh7neHuZeSBakBIXpB3bBchug7yPlIC6sKchKS', 'Hi, Welcome to my Profile.', 'images/profilepictures/30348272.jpg'),
('30349096', 'Shiwam Rawat', 'shiwamrawat413@gmail.com', '$2y$10$8ZBmrtKa4B/kcmKBWQLWMen4XqNyNu7k1oPrsduDPfu7ynnHIZruq', '', ''),
('30350175', 'Aawesh Dhakal', 'aaweshdhakal2056@gmail.com', '$2y$10$tSMgmj6vZBhIrYtjZYnZae6SSTh5A8/kmT0Ex83fOT1RvHe3BPMnC', '', ''),
('tutor', 'Tutor', 'tutor@gmail.com', '$2y$10$N5gBUtQmI1TAHonfogRSbupEStXtr/THqMuYeSvNNLALdXF7JqxhO', '', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cake`
--
ALTER TABLE `cake`
  ADD PRIMARY KEY (`cake_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD KEY `cake_id` (`cake_id`),
  ADD KEY `user_id` (`userid`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD KEY `message_ibfk_1` (`from_user_id`),
  ADD KEY `message_ibfk_2` (`to_user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
